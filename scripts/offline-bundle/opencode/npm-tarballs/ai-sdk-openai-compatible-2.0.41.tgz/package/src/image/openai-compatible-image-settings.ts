export type OpenAICompatibleImageModelId = string;
